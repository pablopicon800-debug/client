package com.pabl.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PablClient implements ClientModInitializer {
    public static final String MOD_ID = "pablclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static KeyBinding openSettingsKey;
    public static PablConfig config;
    public static PablHud hud;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing _pabl client...");

        // Load configuration
        config = new PablConfig();
        config.load();

        // Initialize HUD
        hud = new PablHud();

        // Register keybinding (Right Shift)
        openSettingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pablclient.open_settings",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.pablclient.general"
        ));

        // Register tick event to check for key press
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openSettingsKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new PablSettingsScreen(null));
                }
            }

            // Update HUD
            hud.tick();
        });

        LOGGER.info("_pabl client initialized! Press RIGHT SHIFT to open settings.");
    }
}
