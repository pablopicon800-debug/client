package com.pabl.client.mixin;

import com.pabl.client.PablClient;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public class ItemRendererMixin {

    @Inject(method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/world/World;III)V",
            at = @At("HEAD"))
    private void onRenderItem(LivingEntity entity, ItemStack stack, ModelTransformationMode renderMode, boolean leftHanded, MatrixStack matrices, VertexConsumerProvider vertexConsumers, World world, int light, int overlay, int seed, CallbackInfo ci) {
        if (PablClient.config == null || stack == null || stack.isEmpty()) {
            return;
        }

        // Small Totem
        if (PablClient.config.smallTotem && stack.isOf(Items.TOTEM_OF_UNDYING)) {
            if (renderMode == ModelTransformationMode.FIRST_PERSON_RIGHT_HAND || 
                renderMode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND) {
                matrices.scale(0.5f, 0.5f, 0.5f);
            }
        }

        // Small Shield
        if (PablClient.config.smallShield && stack.isOf(Items.SHIELD)) {
            if (renderMode == ModelTransformationMode.FIRST_PERSON_RIGHT_HAND || 
                renderMode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND) {
                matrices.scale(0.7f, 0.7f, 0.7f);
            }
        }
    }
}
