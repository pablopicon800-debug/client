package com.pabl.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class PablHud {
    private MinecraftClient client;
    private TextRenderer textRenderer;

    // Click tracking
    private int leftClicks = 0;
    private int rightClicks = 0;
    private long lastLeftClick = 0;
    private long lastRightClick = 0;
    private int leftCPS = 0;
    private int rightCPS = 0;

    // Animation
    private float clickAnimationProgress = 0.0f;
    private boolean clickAnimationActive = false;

    public PablHud() {
        this.client = MinecraftClient.getInstance();
        this.textRenderer = client.textRenderer;
    }

    public void tick() {
        // Update CPS
        long currentTime = System.currentTimeMillis();

        if (client.mouse.wasLeftButtonClicked()) {
            leftClicks++;
            lastLeftClick = currentTime;

            if (PablClient.config.clickAnimation) {
                clickAnimationActive = true;
                clickAnimationProgress = 0.0f;
            }
        }

        if (client.mouse.wasRightButtonClicked()) {
            rightClicks++;
            lastRightClick = currentTime;
        }

        // Calculate CPS (clicks in last second)
        if (currentTime - lastLeftClick > 1000) {
            leftCPS = 0;
        } else {
            leftCPS = leftClicks;
        }

        if (currentTime - lastRightClick > 1000) {
            rightCPS = 0;
        } else {
            rightCPS = rightClicks;
        }

        // Reset click counters every second
        if (currentTime % 1000 < 50) {
            leftClicks = 0;
            rightClicks = 0;
        }

        // Update click animation
        if (clickAnimationActive) {
            clickAnimationProgress += 0.1f;
            if (clickAnimationProgress >= 1.0f) {
                clickAnimationActive = false;
                clickAnimationProgress = 0.0f;
            }
        }
    }

    public void render(DrawContext context, RenderTickCounter tickCounter) {
        if (client.player == null || client.getDebugHud().shouldShowDebugHud()) {
            return;
        }

        int color = PablClient.config.getHudColor();
        int textColor = 0xFFFFFF;

        int y = 10;

        // FPS Display
        if (PablClient.config.fpsDisplay) {
            String fpsText = "FPS: " + client.getCurrentFps();
            drawTextWithBackground(context, fpsText, 10, y, textColor, color);
            y += 15;
        }

        // CPS Display
        if (PablClient.config.cpsDisplay) {
            String cpsText = "CPS: " + leftCPS + " | " + rightCPS;
            drawTextWithBackground(context, cpsText, 10, y, textColor, color);
            y += 15;
        }

        // Coordinates
        if (PablClient.config.coordinates) {
            String coords = String.format("XYZ: %.0f %.0f %.0f", 
                client.player.getX(), 
                client.player.getY(), 
                client.player.getZ());
            drawTextWithBackground(context, coords, 10, y, textColor, color);
            y += 15;
        }

        // Armor Status
        if (PablClient.config.armorStatus) {
            renderArmorStatus(context, 10, y, textColor, color);
            y += 15;
        }

        // Keystrokes
        if (PablClient.config.keystrokes) {
            renderKeystrokes(context, 10, context.getScaledWindowHeight() - 80, textColor, color);
        }

        // Click Animation
        if (PablClient.config.clickAnimation && clickAnimationActive) {
            renderClickAnimation(context);
        }
    }

    private void drawTextWithBackground(DrawContext context, String text, int x, int y, int textColor, int bgColor) {
        int width = textRenderer.getWidth(text);
        context.fill(x - 2, y - 2, x + width + 2, y + 10, bgColor);
        context.drawText(textRenderer, text, x, y, textColor, true);
    }

    private void renderArmorStatus(DrawContext context, int x, int y, int textColor, int bgColor) {
        int armorY = y;
        for (ItemStack stack : client.player.getArmorItems()) {
            if (!stack.isEmpty()) {
                String durability = "";
                if (stack.isDamageable()) {
                    int max = stack.getMaxDamage();
                    int current = max - stack.getDamage();
                    durability = String.format(" %d/%d", current, max);
                }
                String itemName = stack.getName().getString();
                drawTextWithBackground(context, itemName + durability, x, armorY, textColor, bgColor);
                armorY += 12;
            }
        }
    }

    private void renderKeystrokes(DrawContext context, int x, int y, int textColor, int bgColor) {
        int keyWidth = 25;
        int keyHeight = 25;
        int spacing = 2;

        // W
        drawKey(context, "W", x + keyWidth + spacing, y, keyWidth, keyHeight, 
            client.player.input.movementForward > 0, textColor, bgColor);

        // A S D
        drawKey(context, "A", x, y + keyHeight + spacing, keyWidth, keyHeight, 
            client.player.input.movementSideways > 0, textColor, bgColor);
        drawKey(context, "S", x + keyWidth + spacing, y + keyHeight + spacing, keyWidth, keyHeight, 
            client.player.input.movementForward < 0, textColor, bgColor);
        drawKey(context, "D", x + (keyWidth + spacing) * 2, y + keyHeight + spacing, keyWidth, keyHeight, 
            client.player.input.movementSideways < 0, textColor, bgColor);

        // Space
        int spaceWidth = keyWidth * 3 + spacing * 2;
        drawKey(context, "SPACE", x, y + (keyHeight + spacing) * 2, spaceWidth, keyHeight, 
            client.player.input.jumping, textColor, bgColor);

        // CPS
        String cpsText = leftCPS + " CPS";
        drawTextWithBackground(context, cpsText, x + spaceWidth + 5, y + (keyHeight + spacing) * 2, textColor, bgColor);
    }

    private void drawKey(DrawContext context, String key, int x, int y, int width, int height, boolean pressed, int textColor, int bgColor) {
        int backgroundColor = pressed ? 0xFFFFFFFF : bgColor;
        int textCol = pressed ? 0x000000 : textColor;

        context.fill(x, y, x + width, y + height, backgroundColor);
        context.drawBorder(x, y, width, height, 0xFF000000);

        int textX = x + (width - textRenderer.getWidth(key)) / 2;
        int textY = y + (height - 8) / 2;
        context.drawText(textRenderer, key, textX, textY, textCol, false);
    }

    private void renderClickAnimation(DrawContext context) {
        int centerX = context.getScaledWindowWidth() / 2;
        int centerY = context.getScaledWindowHeight() / 2;

        float progress = clickAnimationProgress;
        float scale = 1.0f + (progress * 0.5f);
        int size = (int)(20 * scale * PablClient.config.clickAnimationScale);
        int alpha = (int)(255 * (1.0f - progress));

        int color = (alpha << 24) | 0x808080;

        context.fill(centerX - size, centerY - size, centerX + size, centerY + size, color);
    }

    // Particle removal check
    public boolean shouldRemoveParticles() {
        return PablClient.config.removeParticles;
    }

    // Small totem check
    public boolean isSmallTotem() {
        return PablClient.config.smallTotem;
    }

    // Small shield check
    public boolean isSmallShield() {
        return PablClient.config.smallShield;
    }
}
