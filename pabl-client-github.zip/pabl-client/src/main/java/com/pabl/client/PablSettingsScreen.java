package com.pabl.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;

public class PablSettingsScreen extends Screen {
    private final Screen parent;

    public PablSettingsScreen(Screen parent) {
        super(Text.translatable("screen.pablclient.settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        int buttonWidth = 200;
        int buttonHeight = 20;
        int spacing = 24;

        int y = centerY - 80;

        // Title
        // (drawn in render method)

        // FPS Display
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.fpsDisplay)
            .build(centerX - buttonWidth - 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.fps_display"), (button, value) -> {
                    PablClient.config.fpsDisplay = value;
                    PablClient.config.save();
                }));

        // CPS Display
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.cpsDisplay)
            .build(centerX + 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.cps_display"), (button, value) -> {
                    PablClient.config.cpsDisplay = value;
                    PablClient.config.save();
                }));

        y += spacing;

        // Keystrokes
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.keystrokes)
            .build(centerX - buttonWidth - 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.keystrokes"), (button, value) -> {
                    PablClient.config.keystrokes = value;
                    PablClient.config.save();
                }));

        // Coordinates
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.coordinates)
            .build(centerX + 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.coordinates"), (button, value) -> {
                    PablClient.config.coordinates = value;
                    PablClient.config.save();
                }));

        y += spacing;

        // Click Animation
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.clickAnimation)
            .build(centerX - buttonWidth - 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.click_animation"), (button, value) -> {
                    PablClient.config.clickAnimation = value;
                    PablClient.config.save();
                }));

        // Remove Particles
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.removeParticles)
            .build(centerX + 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.remove_particles"), (button, value) -> {
                    PablClient.config.removeParticles = value;
                    PablClient.config.save();
                }));

        y += spacing;

        // Small Totem
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.smallTotem)
            .build(centerX - buttonWidth - 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.small_totem"), (button, value) -> {
                    PablClient.config.smallTotem = value;
                    PablClient.config.save();
                }));

        // Small Shield
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(PablClient.config.smallShield)
            .build(centerX + 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.small_shield"), (button, value) -> {
                    PablClient.config.smallShield = value;
                    PablClient.config.save();
                }));

        y += spacing + 10;

        // HUD Color
        this.addDrawableChild(CyclingButtonWidget.builder((Text text) -> text)
            .values(
                Text.translatable("option.pablclient.gray"),
                Text.translatable("option.pablclient.dark_gray"),
                Text.translatable("option.pablclient.light_gray")
            )
            .initially(Text.translatable("option.pablclient." + PablClient.config.hudColor))
            .build(centerX - buttonWidth - 10, y, buttonWidth, buttonHeight, 
                Text.translatable("option.pablclient.hud_color"), (button, value) -> {
                    String colorName = value.getString().toLowerCase().replace(" ", "_");
                    PablClient.config.setHudColor(colorName);
                    PablClient.config.save();
                }));

        // Reset Button
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("button.pablclient.reset"), (button) -> {
            PablClient.config.reset();
            this.clearChildren();
            this.init();
        }).dimensions(centerX + 10, y, buttonWidth, buttonHeight).build());

        y += spacing + 10;

        // Done Button
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("button.pablclient.done"), (button) -> {
            PablClient.config.save();
            this.client.setScreen(this.parent);
        }).dimensions(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        // Draw title
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);

        // Draw version
        context.drawCenteredTextWithShadow(this.textRenderer, "v1.0.0 for Minecraft 1.21.11", this.width / 2, 35, 0x808080);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        PablClient.config.save();
        this.client.setScreen(this.parent);
    }
}
