package com.pabl.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class PablConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "pablclient.json");

    // HUD Settings
    public boolean fpsDisplay = true;
    public boolean cpsDisplay = true;
    public boolean keystrokes = true;
    public boolean coordinates = true;
    public boolean armorStatus = true;

    // Visual Settings
    public boolean clickAnimation = true;
    public boolean removeParticles = false;
    public boolean totemAnimation = true;
    public boolean smallTotem = false;
    public boolean smallShield = false;

    // Color Settings
    public String hudColor = "gray"; // gray, dark_gray, light_gray
    public int hudColorR = 128;
    public int hudColorG = 128;
    public int hudColorB = 128;
    public int hudColorA = 180;

    // Animation Settings
    public float clickAnimationScale = 1.0f;
    public int clickAnimationDuration = 100; // milliseconds

    public void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                PablConfig loaded = GSON.fromJson(reader, PablConfig.class);
                if (loaded != null) {
                    copyFrom(loaded);
                }
            } catch (IOException e) {
                PablClient.LOGGER.error("Failed to load config", e);
            }
        } else {
            save();
        }
    }

    public void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            PablClient.LOGGER.error("Failed to save config", e);
        }
    }

    public void reset() {
        fpsDisplay = true;
        cpsDisplay = true;
        keystrokes = true;
        coordinates = true;
        armorStatus = true;
        clickAnimation = true;
        removeParticles = false;
        totemAnimation = true;
        smallTotem = false;
        smallShield = false;
        hudColor = "gray";
        hudColorR = 128;
        hudColorG = 128;
        hudColorB = 128;
        hudColorA = 180;
        clickAnimationScale = 1.0f;
        clickAnimationDuration = 100;
        save();
    }

    private void copyFrom(PablConfig other) {
        this.fpsDisplay = other.fpsDisplay;
        this.cpsDisplay = other.cpsDisplay;
        this.keystrokes = other.keystrokes;
        this.coordinates = other.coordinates;
        this.armorStatus = other.armorStatus;
        this.clickAnimation = other.clickAnimation;
        this.removeParticles = other.removeParticles;
        this.totemAnimation = other.totemAnimation;
        this.smallTotem = other.smallTotem;
        this.smallShield = other.smallShield;
        this.hudColor = other.hudColor;
        this.hudColorR = other.hudColorR;
        this.hudColorG = other.hudColorG;
        this.hudColorB = other.hudColorB;
        this.hudColorA = other.hudColorA;
        this.clickAnimationScale = other.clickAnimationScale;
        this.clickAnimationDuration = other.clickAnimationDuration;
    }

    public int getHudColor() {
        return (hudColorA << 24) | (hudColorR << 16) | (hudColorG << 8) | hudColorB;
    }

    public void setHudColor(String colorName) {
        this.hudColor = colorName;
        switch (colorName) {
            case "dark_gray":
                hudColorR = 64; hudColorG = 64; hudColorB = 64;
                break;
            case "light_gray":
                hudColorR = 192; hudColorG = 192; hudColorB = 192;
                break;
            default: // gray
                hudColorR = 128; hudColorG = 128; hudColorB = 128;
                break;
        }
    }
}
